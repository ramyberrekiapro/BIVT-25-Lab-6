var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });

// api/likes.js
var ITEM_RE = /^[a-z0-9-]{1,60}$/;
var VOTER_RE = /^[A-Za-z0-9-]{16,64}$/;
var ACTIONS_PER_WINDOW = 60;
var WINDOW_S = 600;
var schemaReady = null;
function ensureSchema(db) {
  if (!schemaReady) {
    schemaReady = db.batch([
      db.prepare(
        "CREATE TABLE IF NOT EXISTS likes (item TEXT NOT NULL, voter TEXT NOT NULL, created_at INTEGER NOT NULL, PRIMARY KEY (item, voter))"
      ),
      db.prepare(
        "CREATE TABLE IF NOT EXISTS like_actions (ip TEXT NOT NULL, at INTEGER NOT NULL)"
      ),
      db.prepare("CREATE INDEX IF NOT EXISTS like_actions_ip ON like_actions (ip, at)")
    ]).catch((e) => {
      schemaReady = null;
      throw e;
    });
  }
  return schemaReady;
}
__name(ensureSchema, "ensureSchema");
function json(data, status = 200, extra = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "content-type": "application/json; charset=utf-8", ...extra }
  });
}
__name(json, "json");
async function ipKey(request) {
  const ip = request.headers.get("cf-connecting-ip") || "unknown";
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode("lopez:" + ip));
  return [...new Uint8Array(digest)].slice(0, 12).map((b) => b.toString(16).padStart(2, "0")).join("");
}
__name(ipKey, "ipKey");
async function onRequestGet({ env }) {
  if (!env.DB) return json({ error: "database_not_configured" }, 503);
  await ensureSchema(env.DB);
  const { results } = await env.DB.prepare("SELECT item, COUNT(*) AS n FROM likes GROUP BY item").all();
  const counts = {};
  for (const r of results) counts[r.item] = r.n;
  return json({ counts }, 200, { "cache-control": "public, max-age=10" });
}
__name(onRequestGet, "onRequestGet");
async function onRequestPost({ request, env }) {
  if (!env.DB) return json({ error: "database_not_configured" }, 503);
  let body;
  try {
    body = await request.json();
  } catch {
    return json({ error: "bad_request" }, 400);
  }
  const item = typeof body.item === "string" ? body.item : "";
  const voter = typeof body.voter === "string" ? body.voter : "";
  if (!ITEM_RE.test(item) || !VOTER_RE.test(voter) || typeof body.like !== "boolean") {
    return json({ error: "bad_request" }, 400);
  }
  await ensureSchema(env.DB);
  const now = Math.floor(Date.now() / 1e3);
  const ip = await ipKey(request);
  const recent = await env.DB.prepare("SELECT COUNT(*) AS n FROM like_actions WHERE ip = ? AND at > ?").bind(ip, now - WINDOW_S).first("n");
  if (recent >= ACTIONS_PER_WINDOW) return json({ error: "too_many_actions" }, 429);
  const write = body.like ? env.DB.prepare("INSERT OR IGNORE INTO likes (item, voter, created_at) VALUES (?, ?, ?)").bind(item, voter, now) : env.DB.prepare("DELETE FROM likes WHERE item = ? AND voter = ?").bind(item, voter);
  const res = await env.DB.batch([
    write,
    env.DB.prepare("INSERT INTO like_actions (ip, at) VALUES (?, ?)").bind(ip, now),
    env.DB.prepare("DELETE FROM like_actions WHERE at < ?").bind(now - WINDOW_S),
    env.DB.prepare("SELECT COUNT(*) AS n FROM likes WHERE item = ?").bind(item)
  ]);
  const count = res[3].results[0].n;
  return json({ item, count, liked: body.like });
}
__name(onRequestPost, "onRequestPost");

// ../lib/admin.js
var LOGIN_FAILS_MAX = 10;
var LOGIN_WINDOW_S = 900;
function json2(data, status = 200, extra = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store", ...extra }
  });
}
__name(json2, "json");
function noDb() {
  return json2({ error: "database_not_configured" }, 503);
}
__name(noDb, "noDb");
var authSchema = null;
function ensureAuthSchema(db) {
  if (!authSchema) {
    authSchema = db.batch([
      db.prepare("CREATE TABLE IF NOT EXISTS admin_fails (ip TEXT NOT NULL, at INTEGER NOT NULL)"),
      db.prepare("CREATE INDEX IF NOT EXISTS admin_fails_ip ON admin_fails (ip, at)")
    ]).catch((e) => {
      authSchema = null;
      throw e;
    });
  }
  return authSchema;
}
__name(ensureAuthSchema, "ensureAuthSchema");
async function ipKey2(request, salt) {
  const ip = request.headers.get("cf-connecting-ip") || "unknown";
  const d = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(salt + ":" + ip));
  return [...new Uint8Array(d)].slice(0, 12).map((b) => b.toString(16).padStart(2, "0")).join("");
}
__name(ipKey2, "ipKey");
function safeEqual(a, b) {
  const x = new TextEncoder().encode(a), y = new TextEncoder().encode(b);
  let diff = x.length ^ y.length;
  for (let i = 0; i < Math.max(x.length, y.length); i++) diff |= (x[i] || 0) ^ (y[i] || 0);
  return diff === 0;
}
__name(safeEqual, "safeEqual");
async function requireAdmin(request, env) {
  if (!env.DB) return noDb();
  if (!env.ADMIN_PASSWORD) return json2({ error: "ADMIN_PASSWORD is not set" }, 503);
  await ensureAuthSchema(env.DB);
  const now = Math.floor(Date.now() / 1e3);
  const ip = await ipKey2(request, "admin");
  const fails = await env.DB.prepare("SELECT COUNT(*) AS n FROM admin_fails WHERE ip = ? AND at > ?").bind(ip, now - LOGIN_WINDOW_S).first("n");
  if (fails >= LOGIN_FAILS_MAX) return json2({ error: "too_many_attempts" }, 429);
  const auth = request.headers.get("authorization") || "";
  const given = auth.startsWith("Bearer ") ? auth.slice(7) : "";
  if (!given || !safeEqual(given, env.ADMIN_PASSWORD)) {
    await env.DB.batch([
      env.DB.prepare("INSERT INTO admin_fails (ip, at) VALUES (?, ?)").bind(ip, now),
      env.DB.prepare("DELETE FROM admin_fails WHERE at < ?").bind(now - LOGIN_WINDOW_S)
    ]);
    return json2({ error: "unauthorized" }, 401);
  }
  return null;
}
__name(requireAdmin, "requireAdmin");

// api/menu.js
var ID_RE = /^[a-z0-9-]{1,60}$/;
var MAX = { name: 80, desc: 400, price: 30 };
var MAX_PHOTO = 9e5;
var schemaReady2 = null;
function ensureMenuSchema(db) {
  if (!schemaReady2) {
    schemaReady2 = db.prepare(
      `CREATE TABLE IF NOT EXISTS menu_items (
         id TEXT PRIMARY KEY, section TEXT, is_new INTEGER NOT NULL DEFAULT 0,
         name_fr TEXT, name_en TEXT, desc_fr TEXT, desc_en TEXT, price TEXT,
         hidden INTEGER NOT NULL DEFAULT 0, photo TEXT, photo_v INTEGER, updated_at INTEGER NOT NULL)`
    ).run().catch((e) => {
      schemaReady2 = null;
      throw e;
    });
  }
  return schemaReady2;
}
__name(ensureMenuSchema, "ensureMenuSchema");
function field(v, max) {
  if (v === null || v === void 0) return null;
  if (typeof v !== "string") return void 0;
  return v.replace(/\u0000/g, "").trim().slice(0, max);
}
__name(field, "field");
async function onRequestGet2({ env }) {
  if (!env.DB) return json2({ error: "database_not_configured" }, 503);
  await ensureMenuSchema(env.DB);
  const { results } = await env.DB.prepare(
    "SELECT id, section, is_new, name_fr, name_en, desc_fr, desc_en, price, hidden, photo_v, updated_at FROM menu_items ORDER BY updated_at"
  ).all();
  const items = results.map((r) => ({
    ...r,
    is_new: !!r.is_new,
    hidden: !!r.hidden,
    photo: r.photo_v ? `/api/photo?id=${encodeURIComponent(r.id)}&v=${r.photo_v}` : null
  }));
  return json2({ items }, 200, { "cache-control": "public, max-age=5" });
}
__name(onRequestGet2, "onRequestGet");
async function onRequestPut({ request, env }) {
  if (!env.DB) return json2({ error: "database_not_configured" }, 503);
  const denied = await requireAdmin(request, env);
  if (denied) return denied;
  let b;
  try {
    b = await request.json();
  } catch {
    return json2({ error: "bad_request" }, 400);
  }
  const id = typeof b.id === "string" ? b.id : "";
  if (!ID_RE.test(id)) return json2({ error: "bad_id" }, 400);
  const row = {
    section: field(b.section, 40),
    name_fr: field(b.name_fr, MAX.name),
    name_en: field(b.name_en, MAX.name),
    desc_fr: field(b.desc_fr, MAX.desc),
    desc_en: field(b.desc_en, MAX.desc),
    price: field(b.price, MAX.price)
  };
  if (Object.values(row).includes(void 0)) return json2({ error: "bad_request" }, 400);
  if (row.section !== null && !ID_RE.test(row.section)) return json2({ error: "bad_section" }, 400);
  const isNew = b.is_new === true;
  if (isNew && (!row.section || !row.name_fr)) return json2({ error: "name_and_section_required" }, 400);
  const hidden = b.hidden === true ? 1 : 0;
  await ensureMenuSchema(env.DB);
  const now = Date.now();
  let photoSql = "photo = photo, photo_v = photo_v";
  const binds = [];
  if (b.photo === "") {
    photoSql = "photo = NULL, photo_v = NULL";
  } else if (typeof b.photo === "string") {
    if (!/^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/.test(b.photo) || b.photo.length > MAX_PHOTO) {
      return json2({ error: "bad_photo" }, 400);
    }
    photoSql = "photo = ?, photo_v = ?";
    binds.push(b.photo, now);
  }
  await env.DB.prepare(
    `INSERT INTO menu_items (id, section, is_new, name_fr, name_en, desc_fr, desc_en, price, hidden, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
     ON CONFLICT(id) DO UPDATE SET section = excluded.section, is_new = excluded.is_new,
       name_fr = excluded.name_fr, name_en = excluded.name_en, desc_fr = excluded.desc_fr,
       desc_en = excluded.desc_en, price = excluded.price, hidden = excluded.hidden,
       updated_at = excluded.updated_at`
  ).bind(id, row.section, isNew ? 1 : 0, row.name_fr, row.name_en, row.desc_fr, row.desc_en, row.price, hidden, now).run();
  await env.DB.prepare(`UPDATE menu_items SET ${photoSql} WHERE id = ?`).bind(...binds, id).run();
  return json2({ ok: true });
}
__name(onRequestPut, "onRequestPut");
async function onRequestDelete({ request, env }) {
  if (!env.DB) return json2({ error: "database_not_configured" }, 503);
  const denied = await requireAdmin(request, env);
  if (denied) return denied;
  const id = new URL(request.url).searchParams.get("id") || "";
  if (!ID_RE.test(id)) return json2({ error: "bad_id" }, 400);
  await ensureMenuSchema(env.DB);
  await env.DB.prepare("DELETE FROM menu_items WHERE id = ?").bind(id).run();
  return json2({ ok: true });
}
__name(onRequestDelete, "onRequestDelete");

// api/messages.js
var LIMITS = { name: 80, contact: 120, message: 1500 };
var SEND_PER_WINDOW = 5;
var SEND_WINDOW_S = 600;
var ID_RE2 = /^[0-9a-f-]{36}$/;
var schemaReady3 = null;
function ensureSchema2(db) {
  if (!schemaReady3) {
    schemaReady3 = db.batch([
      db.prepare(`CREATE TABLE IF NOT EXISTS messages (
        id TEXT PRIMARY KEY, name TEXT, contact TEXT, message TEXT NOT NULL, lang TEXT,
        date TEXT NOT NULL, read INTEGER NOT NULL DEFAULT 0)`),
      db.prepare("CREATE TABLE IF NOT EXISTS message_rate (ip TEXT NOT NULL, at INTEGER NOT NULL)"),
      db.prepare("CREATE INDEX IF NOT EXISTS message_rate_ip ON message_rate (ip, at)")
    ]).catch((e) => {
      schemaReady3 = null;
      throw e;
    });
  }
  return schemaReady3;
}
__name(ensureSchema2, "ensureSchema");
function clean(v, max) {
  return typeof v === "string" ? v.replace(/\u0000/g, "").trim().slice(0, max) : "";
}
__name(clean, "clean");
async function onRequestPost2({ request, env }) {
  if (!env.DB) return noDb();
  let body;
  try {
    body = await request.json();
  } catch {
    return json2({ error: "bad_request" }, 400);
  }
  if (clean(body.website, 200)) return json2({ ok: true });
  const msg = {
    name: clean(body.name, LIMITS.name),
    contact: clean(body.contact, LIMITS.contact),
    message: clean(body.message, LIMITS.message),
    lang: body.lang === "en" ? "en" : "fr"
  };
  if (msg.message.length < 2) return json2({ error: "empty_message" }, 400);
  await ensureSchema2(env.DB);
  const now = Math.floor(Date.now() / 1e3);
  const ip = await ipKey2(request, "msg");
  const recent = await env.DB.prepare("SELECT COUNT(*) AS n FROM message_rate WHERE ip = ? AND at > ?").bind(ip, now - SEND_WINDOW_S).first("n");
  if (recent >= SEND_PER_WINDOW) return json2({ error: "too_many_messages" }, 429);
  await env.DB.batch([
    env.DB.prepare("INSERT INTO messages (id, name, contact, message, lang, date, read) VALUES (?, ?, ?, ?, ?, ?, 0)").bind(crypto.randomUUID(), msg.name, msg.contact, msg.message, msg.lang, (/* @__PURE__ */ new Date()).toISOString()),
    env.DB.prepare("INSERT INTO message_rate (ip, at) VALUES (?, ?)").bind(ip, now),
    env.DB.prepare("DELETE FROM message_rate WHERE at < ?").bind(now - SEND_WINDOW_S)
  ]);
  return json2({ ok: true });
}
__name(onRequestPost2, "onRequestPost");
async function onRequestGet3({ request, env }) {
  const denied = await requireAdmin(request, env);
  if (denied) return denied;
  await ensureSchema2(env.DB);
  const { results } = await env.DB.prepare(
    "SELECT id, name, contact, message, lang, date, read FROM messages ORDER BY date DESC LIMIT 201"
  ).all();
  const more = results.length > 200;
  const messages = results.slice(0, 200).map((m) => ({ ...m, read: !!m.read }));
  return json2({ messages, more });
}
__name(onRequestGet3, "onRequestGet");
async function withMessage(request, env, fn) {
  const denied = await requireAdmin(request, env);
  if (denied) return denied;
  const id = new URL(request.url).searchParams.get("id") || "";
  if (!ID_RE2.test(id)) return json2({ error: "bad_id" }, 400);
  await ensureSchema2(env.DB);
  return fn(id);
}
__name(withMessage, "withMessage");
async function onRequestPatch({ request, env }) {
  return withMessage(request, env, async (id) => {
    let body = {};
    try {
      body = await request.json();
    } catch {
    }
    const r = await env.DB.prepare("UPDATE messages SET read = ? WHERE id = ?").bind(body.read !== false ? 1 : 0, id).run();
    if (!r.meta.changes) return json2({ error: "not_found" }, 404);
    return json2({ ok: true });
  });
}
__name(onRequestPatch, "onRequestPatch");
async function onRequestDelete2({ request, env }) {
  return withMessage(request, env, async (id) => {
    await env.DB.prepare("DELETE FROM messages WHERE id = ?").bind(id).run();
    return json2({ ok: true });
  });
}
__name(onRequestDelete2, "onRequestDelete");

// api/photo.js
async function onRequestGet4({ request, env }) {
  if (!env.DB) return new Response("Not found", { status: 404 });
  const id = new URL(request.url).searchParams.get("id") || "";
  if (!/^[a-z0-9-]{1,60}$/.test(id)) return new Response("Not found", { status: 404 });
  await ensureMenuSchema(env.DB);
  const photo = await env.DB.prepare("SELECT photo FROM menu_items WHERE id = ?").bind(id).first("photo");
  const m = typeof photo === "string" && photo.match(/^data:(image\/(?:jpeg|png|webp));base64,(.+)$/);
  if (!m) return new Response("Not found", { status: 404 });
  const bytes = Uint8Array.from(atob(m[2]), (c) => c.charCodeAt(0));
  return new Response(bytes, {
    headers: { "content-type": m[1], "cache-control": "public, max-age=31536000, immutable" }
  });
}
__name(onRequestGet4, "onRequestGet");

// ../.wrangler/tmp/pages-zYfvMQ/functionsRoutes-0.338335994424263.mjs
var routes = [
  {
    routePath: "/api/likes",
    mountPath: "/api",
    method: "GET",
    middlewares: [],
    modules: [onRequestGet]
  },
  {
    routePath: "/api/likes",
    mountPath: "/api",
    method: "POST",
    middlewares: [],
    modules: [onRequestPost]
  },
  {
    routePath: "/api/menu",
    mountPath: "/api",
    method: "DELETE",
    middlewares: [],
    modules: [onRequestDelete]
  },
  {
    routePath: "/api/menu",
    mountPath: "/api",
    method: "GET",
    middlewares: [],
    modules: [onRequestGet2]
  },
  {
    routePath: "/api/menu",
    mountPath: "/api",
    method: "PUT",
    middlewares: [],
    modules: [onRequestPut]
  },
  {
    routePath: "/api/messages",
    mountPath: "/api",
    method: "DELETE",
    middlewares: [],
    modules: [onRequestDelete2]
  },
  {
    routePath: "/api/messages",
    mountPath: "/api",
    method: "GET",
    middlewares: [],
    modules: [onRequestGet3]
  },
  {
    routePath: "/api/messages",
    mountPath: "/api",
    method: "PATCH",
    middlewares: [],
    modules: [onRequestPatch]
  },
  {
    routePath: "/api/messages",
    mountPath: "/api",
    method: "POST",
    middlewares: [],
    modules: [onRequestPost2]
  },
  {
    routePath: "/api/photo",
    mountPath: "/api",
    method: "GET",
    middlewares: [],
    modules: [onRequestGet4]
  }
];

// ../../../../../../root/.npm/_npx/c943b712072b77c4/node_modules/path-to-regexp/dist.es2015/index.js
function lexer(str) {
  var tokens = [];
  var i = 0;
  while (i < str.length) {
    var char = str[i];
    if (char === "*" || char === "+" || char === "?") {
      tokens.push({ type: "MODIFIER", index: i, value: str[i++] });
      continue;
    }
    if (char === "\\") {
      tokens.push({ type: "ESCAPED_CHAR", index: i++, value: str[i++] });
      continue;
    }
    if (char === "{") {
      tokens.push({ type: "OPEN", index: i, value: str[i++] });
      continue;
    }
    if (char === "}") {
      tokens.push({ type: "CLOSE", index: i, value: str[i++] });
      continue;
    }
    if (char === ":") {
      var name = "";
      var j = i + 1;
      while (j < str.length) {
        var code = str.charCodeAt(j);
        if (
          // `0-9`
          code >= 48 && code <= 57 || // `A-Z`
          code >= 65 && code <= 90 || // `a-z`
          code >= 97 && code <= 122 || // `_`
          code === 95
        ) {
          name += str[j++];
          continue;
        }
        break;
      }
      if (!name)
        throw new TypeError("Missing parameter name at ".concat(i));
      tokens.push({ type: "NAME", index: i, value: name });
      i = j;
      continue;
    }
    if (char === "(") {
      var count = 1;
      var pattern = "";
      var j = i + 1;
      if (str[j] === "?") {
        throw new TypeError('Pattern cannot start with "?" at '.concat(j));
      }
      while (j < str.length) {
        if (str[j] === "\\") {
          pattern += str[j++] + str[j++];
          continue;
        }
        if (str[j] === ")") {
          count--;
          if (count === 0) {
            j++;
            break;
          }
        } else if (str[j] === "(") {
          count++;
          if (str[j + 1] !== "?") {
            throw new TypeError("Capturing groups are not allowed at ".concat(j));
          }
        }
        pattern += str[j++];
      }
      if (count)
        throw new TypeError("Unbalanced pattern at ".concat(i));
      if (!pattern)
        throw new TypeError("Missing pattern at ".concat(i));
      tokens.push({ type: "PATTERN", index: i, value: pattern });
      i = j;
      continue;
    }
    tokens.push({ type: "CHAR", index: i, value: str[i++] });
  }
  tokens.push({ type: "END", index: i, value: "" });
  return tokens;
}
__name(lexer, "lexer");
function parse(str, options) {
  if (options === void 0) {
    options = {};
  }
  var tokens = lexer(str);
  var _a = options.prefixes, prefixes = _a === void 0 ? "./" : _a, _b = options.delimiter, delimiter = _b === void 0 ? "/#?" : _b;
  var result = [];
  var key = 0;
  var i = 0;
  var path = "";
  var tryConsume = /* @__PURE__ */ __name(function(type) {
    if (i < tokens.length && tokens[i].type === type)
      return tokens[i++].value;
  }, "tryConsume");
  var mustConsume = /* @__PURE__ */ __name(function(type) {
    var value2 = tryConsume(type);
    if (value2 !== void 0)
      return value2;
    var _a2 = tokens[i], nextType = _a2.type, index = _a2.index;
    throw new TypeError("Unexpected ".concat(nextType, " at ").concat(index, ", expected ").concat(type));
  }, "mustConsume");
  var consumeText = /* @__PURE__ */ __name(function() {
    var result2 = "";
    var value2;
    while (value2 = tryConsume("CHAR") || tryConsume("ESCAPED_CHAR")) {
      result2 += value2;
    }
    return result2;
  }, "consumeText");
  var isSafe = /* @__PURE__ */ __name(function(value2) {
    for (var _i = 0, delimiter_1 = delimiter; _i < delimiter_1.length; _i++) {
      var char2 = delimiter_1[_i];
      if (value2.indexOf(char2) > -1)
        return true;
    }
    return false;
  }, "isSafe");
  var safePattern = /* @__PURE__ */ __name(function(prefix2) {
    var prev = result[result.length - 1];
    var prevText = prefix2 || (prev && typeof prev === "string" ? prev : "");
    if (prev && !prevText) {
      throw new TypeError('Must have text between two parameters, missing text after "'.concat(prev.name, '"'));
    }
    if (!prevText || isSafe(prevText))
      return "[^".concat(escapeString(delimiter), "]+?");
    return "(?:(?!".concat(escapeString(prevText), ")[^").concat(escapeString(delimiter), "])+?");
  }, "safePattern");
  while (i < tokens.length) {
    var char = tryConsume("CHAR");
    var name = tryConsume("NAME");
    var pattern = tryConsume("PATTERN");
    if (name || pattern) {
      var prefix = char || "";
      if (prefixes.indexOf(prefix) === -1) {
        path += prefix;
        prefix = "";
      }
      if (path) {
        result.push(path);
        path = "";
      }
      result.push({
        name: name || key++,
        prefix,
        suffix: "",
        pattern: pattern || safePattern(prefix),
        modifier: tryConsume("MODIFIER") || ""
      });
      continue;
    }
    var value = char || tryConsume("ESCAPED_CHAR");
    if (value) {
      path += value;
      continue;
    }
    if (path) {
      result.push(path);
      path = "";
    }
    var open = tryConsume("OPEN");
    if (open) {
      var prefix = consumeText();
      var name_1 = tryConsume("NAME") || "";
      var pattern_1 = tryConsume("PATTERN") || "";
      var suffix = consumeText();
      mustConsume("CLOSE");
      result.push({
        name: name_1 || (pattern_1 ? key++ : ""),
        pattern: name_1 && !pattern_1 ? safePattern(prefix) : pattern_1,
        prefix,
        suffix,
        modifier: tryConsume("MODIFIER") || ""
      });
      continue;
    }
    mustConsume("END");
  }
  return result;
}
__name(parse, "parse");
function match(str, options) {
  var keys = [];
  var re = pathToRegexp(str, keys, options);
  return regexpToFunction(re, keys, options);
}
__name(match, "match");
function regexpToFunction(re, keys, options) {
  if (options === void 0) {
    options = {};
  }
  var _a = options.decode, decode = _a === void 0 ? function(x) {
    return x;
  } : _a;
  return function(pathname) {
    var m = re.exec(pathname);
    if (!m)
      return false;
    var path = m[0], index = m.index;
    var params = /* @__PURE__ */ Object.create(null);
    var _loop_1 = /* @__PURE__ */ __name(function(i2) {
      if (m[i2] === void 0)
        return "continue";
      var key = keys[i2 - 1];
      if (key.modifier === "*" || key.modifier === "+") {
        params[key.name] = m[i2].split(key.prefix + key.suffix).map(function(value) {
          return decode(value, key);
        });
      } else {
        params[key.name] = decode(m[i2], key);
      }
    }, "_loop_1");
    for (var i = 1; i < m.length; i++) {
      _loop_1(i);
    }
    return { path, index, params };
  };
}
__name(regexpToFunction, "regexpToFunction");
function escapeString(str) {
  return str.replace(/([.+*?=^!:${}()[\]|/\\])/g, "\\$1");
}
__name(escapeString, "escapeString");
function flags(options) {
  return options && options.sensitive ? "" : "i";
}
__name(flags, "flags");
function regexpToRegexp(path, keys) {
  if (!keys)
    return path;
  var groupsRegex = /\((?:\?<(.*?)>)?(?!\?)/g;
  var index = 0;
  var execResult = groupsRegex.exec(path.source);
  while (execResult) {
    keys.push({
      // Use parenthesized substring match if available, index otherwise
      name: execResult[1] || index++,
      prefix: "",
      suffix: "",
      modifier: "",
      pattern: ""
    });
    execResult = groupsRegex.exec(path.source);
  }
  return path;
}
__name(regexpToRegexp, "regexpToRegexp");
function arrayToRegexp(paths, keys, options) {
  var parts = paths.map(function(path) {
    return pathToRegexp(path, keys, options).source;
  });
  return new RegExp("(?:".concat(parts.join("|"), ")"), flags(options));
}
__name(arrayToRegexp, "arrayToRegexp");
function stringToRegexp(path, keys, options) {
  return tokensToRegexp(parse(path, options), keys, options);
}
__name(stringToRegexp, "stringToRegexp");
function tokensToRegexp(tokens, keys, options) {
  if (options === void 0) {
    options = {};
  }
  var _a = options.strict, strict = _a === void 0 ? false : _a, _b = options.start, start = _b === void 0 ? true : _b, _c = options.end, end = _c === void 0 ? true : _c, _d = options.encode, encode = _d === void 0 ? function(x) {
    return x;
  } : _d, _e = options.delimiter, delimiter = _e === void 0 ? "/#?" : _e, _f = options.endsWith, endsWith = _f === void 0 ? "" : _f;
  var endsWithRe = "[".concat(escapeString(endsWith), "]|$");
  var delimiterRe = "[".concat(escapeString(delimiter), "]");
  var route = start ? "^" : "";
  for (var _i = 0, tokens_1 = tokens; _i < tokens_1.length; _i++) {
    var token = tokens_1[_i];
    if (typeof token === "string") {
      route += escapeString(encode(token));
    } else {
      var prefix = escapeString(encode(token.prefix));
      var suffix = escapeString(encode(token.suffix));
      if (token.pattern) {
        if (keys)
          keys.push(token);
        if (prefix || suffix) {
          if (token.modifier === "+" || token.modifier === "*") {
            var mod = token.modifier === "*" ? "?" : "";
            route += "(?:".concat(prefix, "((?:").concat(token.pattern, ")(?:").concat(suffix).concat(prefix, "(?:").concat(token.pattern, "))*)").concat(suffix, ")").concat(mod);
          } else {
            route += "(?:".concat(prefix, "(").concat(token.pattern, ")").concat(suffix, ")").concat(token.modifier);
          }
        } else {
          if (token.modifier === "+" || token.modifier === "*") {
            throw new TypeError('Can not repeat "'.concat(token.name, '" without a prefix and suffix'));
          }
          route += "(".concat(token.pattern, ")").concat(token.modifier);
        }
      } else {
        route += "(?:".concat(prefix).concat(suffix, ")").concat(token.modifier);
      }
    }
  }
  if (end) {
    if (!strict)
      route += "".concat(delimiterRe, "?");
    route += !options.endsWith ? "$" : "(?=".concat(endsWithRe, ")");
  } else {
    var endToken = tokens[tokens.length - 1];
    var isEndDelimited = typeof endToken === "string" ? delimiterRe.indexOf(endToken[endToken.length - 1]) > -1 : endToken === void 0;
    if (!strict) {
      route += "(?:".concat(delimiterRe, "(?=").concat(endsWithRe, "))?");
    }
    if (!isEndDelimited) {
      route += "(?=".concat(delimiterRe, "|").concat(endsWithRe, ")");
    }
  }
  return new RegExp(route, flags(options));
}
__name(tokensToRegexp, "tokensToRegexp");
function pathToRegexp(path, keys, options) {
  if (path instanceof RegExp)
    return regexpToRegexp(path, keys);
  if (Array.isArray(path))
    return arrayToRegexp(path, keys, options);
  return stringToRegexp(path, keys, options);
}
__name(pathToRegexp, "pathToRegexp");

// ../../../../../../root/.npm/_npx/c943b712072b77c4/node_modules/wrangler/templates/pages-template-worker.ts
var escapeRegex = /[.+?^${}()|[\]\\]/g;
function* executeRequest(request) {
  const requestPath = new URL(request.url).pathname;
  for (const route of [...routes].reverse()) {
    if (route.method && route.method !== request.method) {
      continue;
    }
    const routeMatcher = match(route.routePath.replace(escapeRegex, "\\$&"), {
      end: false
    });
    const mountMatcher = match(route.mountPath.replace(escapeRegex, "\\$&"), {
      end: false
    });
    const matchResult = routeMatcher(requestPath);
    const mountMatchResult = mountMatcher(requestPath);
    if (matchResult && mountMatchResult) {
      for (const handler of route.middlewares.flat()) {
        yield {
          handler,
          params: matchResult.params,
          path: mountMatchResult.path
        };
      }
    }
  }
  for (const route of routes) {
    if (route.method && route.method !== request.method) {
      continue;
    }
    const routeMatcher = match(route.routePath.replace(escapeRegex, "\\$&"), {
      end: true
    });
    const mountMatcher = match(route.mountPath.replace(escapeRegex, "\\$&"), {
      end: false
    });
    const matchResult = routeMatcher(requestPath);
    const mountMatchResult = mountMatcher(requestPath);
    if (matchResult && mountMatchResult && route.modules.length) {
      for (const handler of route.modules.flat()) {
        yield {
          handler,
          params: matchResult.params,
          path: matchResult.path
        };
      }
      break;
    }
  }
}
__name(executeRequest, "executeRequest");
var pages_template_worker_default = {
  async fetch(originalRequest, env, workerContext) {
    let request = originalRequest;
    const handlerIterator = executeRequest(request);
    let data = {};
    let isFailOpen = false;
    const next = /* @__PURE__ */ __name(async (input, init) => {
      if (input !== void 0) {
        let url = input;
        if (typeof input === "string") {
          url = new URL(input, request.url).toString();
        }
        request = new Request(url, init);
      }
      const result = handlerIterator.next();
      if (result.done === false) {
        const { handler, params, path } = result.value;
        const context = {
          request: new Request(request.clone()),
          functionPath: path,
          next,
          params,
          get data() {
            return data;
          },
          set data(value) {
            if (typeof value !== "object" || value === null) {
              throw new Error("context.data must be an object");
            }
            data = value;
          },
          env,
          waitUntil: workerContext.waitUntil.bind(workerContext),
          passThroughOnException: /* @__PURE__ */ __name(() => {
            isFailOpen = true;
          }, "passThroughOnException")
        };
        const response = await handler(context);
        if (!(response instanceof Response)) {
          throw new Error("Your Pages function should return a Response");
        }
        return cloneResponse(response);
      } else if ("ASSETS") {
        const response = await env["ASSETS"].fetch(request);
        return cloneResponse(response);
      } else {
        const response = await fetch(request);
        return cloneResponse(response);
      }
    }, "next");
    try {
      return await next();
    } catch (error) {
      if (isFailOpen) {
        const response = await env["ASSETS"].fetch(request);
        return cloneResponse(response);
      }
      throw error;
    }
  }
};
var cloneResponse = /* @__PURE__ */ __name((response) => (
  // https://fetch.spec.whatwg.org/#null-body-status
  new Response(
    [101, 204, 205, 304].includes(response.status) ? null : response.body,
    response
  )
), "cloneResponse");
export {
  pages_template_worker_default as default
};
