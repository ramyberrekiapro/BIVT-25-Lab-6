# Lopez — menu website + owner's admin

- **Customer website** `/` — menu (French / English), likes, message form.
- **Owner's admin** `/admin/` — separate private page, not linked anywhere on the customer site,
  hidden from search engines, password required: Orders (café ordering / cash register),
  Messages, Menu (items and categories), Likes,
  Contact (section title and text, Instagram, Google Maps link, address, phone, e-mail).

Both use the same server API (`/api/...`) and the same Cloudflare **D1** database:

```
Customer website (/)          Owner's admin (/admin/)
        │                             │  session cookie (after password)
        └──────────►  /api/...  ◄─────┘
                         │
                     D1 database (DB)
```

It is a **Cloudflare Pages** project: static files in `public/`, server code in `functions/`.

## Project structure

```
public/                   website files
  index.html              customer menu
  admin/index.html        owner's admin
  img/                    menu photos
  menu-data.json          original menu data (used by the admin)
  _headers                no-index / no-cache / no-framing for /admin/
functions/api/            server routes
  likes.js                /api/likes            like counts
  messages.js             /api/messages         send (public) / read, mark, delete (owner)
  menu.js                 /api/menu             menu changes + categories: read (public) / write (owner)
  sections.js             /api/sections         categories: add, remove, rename, reorder (owner)
  site.js                 /api/site             contact details: read (public) / write (owner)
  orders.js               /api/orders           café orders: create, list, status, cash payment (signed in)
  photo.js                /api/photo            photos uploaded in the admin
  admin/login.js          /api/admin/login      sign in -> session cookie
  admin/logout.js         /api/admin/logout
  admin/session.js        /api/admin/session    signed in? must change password?
  admin/password.js       /api/admin/password   change the owner's password
  _middleware.js          turns unexpected errors into JSON errors for the admin
lib/admin.js              password + session checks shared by all routes
lib/sections.js           categories: built-in list + owner's changes
lib/menu.js               current menu with prices, used to price orders on the server
tools/                    maintenance scripts (not needed to run the site)
```

No build step, no npm packages, no `wrangler.toml` (bindings are set in the dashboard).

## Password and security

- **Initial password**: the Cloudflare secret `ADMIN_PASSWORD` (for the first setup: `0000`).
  It only lets the owner into a "choose your password" screen; nothing else opens until a new
  password is set.
- **Owner's password**: chosen in the admin (8+ characters). Stored in D1 only as a salted
  PBKDF2-SHA256 hash. From that moment `ADMIN_PASSWORD` (0000) no longer works.
- The password is never in the website files, in GitHub, or in browser storage. After signing in
  the browser holds only a random session token in an HttpOnly, Secure, SameSite=Strict cookie
  (12 hours); D1 stores only a hash of it. Changing the password signs out all other devices.
- 10 wrong passwords from one connection lock sign-in for 15 minutes.

## Deploy on Cloudflare Pages (from GitHub)

1. Put these files at the top level of your GitHub repository.
2. Cloudflare → **Workers & Pages** → **Create** → **Pages** → **Connect to Git** → your repository.
3. Framework preset **None**, Build command *(empty)*, Build output directory `public`,
   Root directory *(empty)*, Production branch `main` → **Save and Deploy**.
4. Project → **Settings**:
   - **Bindings** → **+ Add** → **D1 database** → name `DB` → your database (e.g. `lopez-db`).
   - **Variables and Secrets** → **+ Add** → Type **Secret**, name `ADMIN_PASSWORD`, value `0000`.
5. **Deployments** → **⋯** → **Retry deployment**.

Check: `/api/likes` → `{"counts":{...}}`, then open `/admin/`.

## First login and changing the password

1. Open `https://<your-address>/admin/`, enter `0000` → **Entrer / Sign in**.
2. The "Choisissez votre mot de passe / Choose your password" screen opens:
   current password `0000`, new password twice (8+ characters) → **Enregistrer / Save**.
3. The admin opens. From now on sign in with the new password.
4. To change it later: **Mot de passe / Password** button (top of the admin) → current password,
   new password twice → **Enregistrer / Save**.

## Forgotten password

Cloudflare → **Storage & Databases** → **D1** → your database → **Console**, run:

```sql
DELETE FROM admin_settings WHERE key = 'password';
```

Then sign in with `ADMIN_PASSWORD` (e.g. `0000`) and choose a new password.
(To use a different temporary password, change the `ADMIN_PASSWORD` secret and retry the deployment.)

## Orders (cash only)

Admin → **Commandes / Orders** (the first tab after signing in):

1. **+ Nouvelle commande / New order** → table number → tap **+** on the items (search box at the
   top), adjust quantities with − / + → the total is calculated → **Créer la commande / Create
   order**. Each order gets the next order number (N° 0001, 0002, …; never reused).
   Items whose menu price is "Prix sur place" ask for their price.
2. New orders appear by themselves on every signed-in screen within about 5 seconds (with a short
   beep and a counter on the tab), no refresh needed.
3. Status buttons: **Nouvelle / New → En préparation / Preparing → Prête / Ready → Payée / Paid →
   Terminée / Completed**. Paid and Completed need a recorded payment.
4. **Encaisser / Take cash** → amount received (or a quick amount button) → the change is shown →
   **Valider le paiement / Confirm payment**. The order becomes Paid. Cash only.
5. **Imprimer le ticket / Print receipt** → the browser's print window. Choose the café receipt
   printer (paper width: **Ticket 80 mm / 58 mm** above the list, remembered on that device) or
   any normal printer.

**En cours / Active** shows orders not yet completed; **Toutes / All** shows every order.
Prices are taken from the menu on the server when the order is created and stored with the order,
so later menu price changes do not change past orders. Stored in the D1 tables `orders` and
`order_items`:

```sql
SELECT * FROM orders ORDER BY id DESC LIMIT 20;
SELECT * FROM order_items WHERE order_id = 1;
```

Staff sign in with the admin password, so they can also use the other admin tabs.

## Categories

Admin → **Menu** → **Catégories / Categories**: rename (French and English), reorder with ↑ ↓,
add, delete, then **Enregistrer / Save**. To move an item to another category: **Modifier / Edit**
→ **Catégorie / Category**. A new category stays hidden on the menu until it has a visible item.
Stored in the D1 table `menu_sections`.

Any category can be deleted, built-in ones included. A deleted built-in category is stored in D1
(`removed = 1`), so it stays deleted after a refresh or a redeploy. Its items disappear from the
customer menu but are not deleted: the admin lists them under **Sans catégorie / No category**,
where each can be moved to another category to show it again.

## Contact details

Admin → **Contact**: section title and text (French / English), Instagram (@name or link),
Google Maps link, address, phone number, e-mail. They appear in the "Écrivez-nous / Write to us"
section (phone as tap-to-call, e-mail as a mail link); Instagram and Location also at the top of
the menu. An empty field is hidden (an empty title goes back to "Écrivez-nous" / "Write to us").
Until saved, the texts and links the site already showed are used. Stored in the D1 table
`site_settings`.

## Where menu changes are stored

Every change made in **Menu** on `/admin/` (added items, prices, names, descriptions, hidden /
shown, photos) is written to the D1 table `menu_items` before the admin says
**Enregistré / Saved**. The admin and the public menu then read it back from D1 (`GET /api/menu`,
not cached), so changes are still there after a reload, on any device.

To see the saved rows: Cloudflare → **Storage & Databases** → **D1** → your database → **Console**:

```sql
SELECT id, section, is_new, name_fr, price, hidden FROM menu_items;
SELECT * FROM menu_sections ORDER BY position;
SELECT * FROM site_settings;
```

If the admin shows "Base D1 non configurée / D1 binding DB missing", the `DB` binding is missing
on the **Production** environment of the Pages project (Settings → Bindings), or the deployment
was not retried after adding it.

## Updating

Push to the production branch; Cloudflare redeploys automatically. Menu changes, messages, likes
and the owner's password live in D1 and survive redeploys.

## Run locally (optional, needs Node.js)

```
npx wrangler pages dev public --d1 DB --binding ADMIN_PASSWORD=0000
```
